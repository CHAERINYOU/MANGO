package com.itwill.controller;

import org.springframework.web.bind.annotation.GetMapping;

@org.springframework.stereotype.Controller
public class Controller {
	
	@GetMapping("/userfavoritegrid")
	public String userfavoritegrid() {
		String forwardPath ="userfavoritegrid";
		return forwardPath;
		
	}
	@GetMapping("/index")
	public String index() {
		String forwardPath ="index";
		return forwardPath;
		
	}
	@GetMapping("user_login_form")
	public String user_login_form() {
		String forwardPath ="user_login_form";
		return forwardPath;
	}
	
	@GetMapping("/include_common")
	public String include_common() {
		String forwardPath ="include_common";
		return forwardPath;
	}
	@GetMapping("/view")
	public String view() {
		String forwardPath ="view";
		return forwardPath;
	}
	@GetMapping("/edit")
	public String edit() {
		String forwardPath ="edit";
		return forwardPath;
	}
	@GetMapping("/write")
	public String write() {
		String forwardPath ="write";
		return forwardPath;
	}
	@GetMapping("/question")
	public String question() {
		String forwardPath ="question";
		return forwardPath;
	}


	
}


